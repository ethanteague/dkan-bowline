# Drupal Console Dotenv Component

This project contains a new command to setup dotenv dependency and configuration on a drupal site. 

### Install on a site:
```
cd /path/to/drupal/

composer require drupal/console-dotenv
```