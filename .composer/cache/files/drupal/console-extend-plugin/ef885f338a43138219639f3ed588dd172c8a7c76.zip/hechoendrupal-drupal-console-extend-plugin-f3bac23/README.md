# Drupal Console Extend Plugin

Composer plugin to discover Drupal Console commands using a standard package/library.

### Install this project:
```
composer require drupal/console-extend-plugin
```
