# Consolidation Output Formatters

This is a placeholder for the output formatters documentation.
